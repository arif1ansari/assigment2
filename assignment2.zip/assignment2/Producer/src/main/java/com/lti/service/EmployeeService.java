package com.lti.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.repository.EmployeeRepository;
import com.lti.model.CustomerModel;

//defining the business logic
@Service
public class EmployeeService 
{
@Autowired
EmployeeRepository employeeRepository;
//getting all employee records
public List<CustomerModel> getAllemployee() 
{
List<CustomerModel> employees = new ArrayList<CustomerModel>();
employeeRepository.findAll().forEach(employee -> employees.add(employee));
return employees;
}
//getting a specific record
public CustomerModel getemployeeById(int id) 
{ //Optional<employee> s=employeeRepository.findById(id);
	//s.orElse(0);
//return s.get();
	
	return employeeRepository.findById(id).get();
}
public void saveOrUpdate(CustomerModel employee) 
{
     //employee s=employeeRepository.persist(employee);
	employeeRepository.save(employee);
	//employeeRepository.flush();
     
}
//deleting a specific record
public void delete(int id) 
{
employeeRepository.deleteById(id);
}
}