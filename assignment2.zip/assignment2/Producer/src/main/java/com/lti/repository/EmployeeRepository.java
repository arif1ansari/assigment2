package com.lti.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.lti.model.CustomerModel;

public interface EmployeeRepository extends JpaRepository<CustomerModel, Integer>
{ /*
	 * @Query("delete from table where age=?age") public void deleteByAge(int age);
	 */
	
	
}
