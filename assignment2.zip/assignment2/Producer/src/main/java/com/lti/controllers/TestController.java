package com.lti.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.CustomerModel;
import com.lti.service.EmployeeService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@RestController

public class TestController {
	
	
	@RequestMapping(value="/staffservice")
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public CustomerModel getStaffdetails() {
		
		CustomerModel emp = new CustomerModel();
		emp.setId(1000);
		emp.setName("Arti");
		emp.setAge(19);
		emp.setEmail("arti11@gmail.com");
		emp.setTypeOfAccount("saving");
		
		if(emp.getName().equalsIgnoreCase("Arti"))
			throw new RuntimeException();

		return emp;

	}
	
public CustomerModel getDataFallBack() {
		
	CustomerModel emp = new CustomerModel();
	emp.setId(1000);
	emp.setName("Arti from fallback");
	emp.setAge(19);
	emp.setEmail("arti11@gmail.com-fallback");
	emp.setTypeOfAccount("saving-fallback");

		return emp;
		
	}

	
	@Autowired
	EmployeeService employeeService;
	//creating a get mapping that retrieves all the employees detail from the database 
	@GetMapping("/employee")   // /api/employee
	private List<CustomerModel> getAllemployee() 
	{
	return employeeService.getAllemployee();
	}
	//creating a get mapping that retrieves the detail of a specific employee
	@GetMapping("/employee/{id}")     //   /api/employee/2
	//@Produces(MediaType.APPLICATION_JSON)
	private CustomerModel getemployee(@PathVariable("id") int id) 
	{
	return employeeService.getemployeeById(id);
	}
	//creating a delete mapping that deletes a specific employee
	@DeleteMapping("/employee/{id}")
	private void deleteemployee(@PathVariable("id") int id) 
	{
	employeeService.delete(id);
	}
	//creating post mapping that post the employee detail in the database
	//@PostMapping(value="/employee",consumes= {"application/json"})
	//@Consumes(MediaType.APPLICATION_JSON)
	@PostMapping("/employee")
	private ResponseEntity<Integer> saveemployee(@RequestBody CustomerModel employee) 
	{
	employeeService.saveOrUpdate(employee);
	return new ResponseEntity(employee.getId(),HttpStatus.OK);
	}

	@PutMapping("/employee")
	private String updateemployee(@RequestBody CustomerModel employee) {
		
		CustomerModel employee1=new CustomerModel();
		employee1.setName(employee.getName());
		employee1.setEmail(employee.getEmail());
		employee1.setAge(employee.getAge());
		employeeService.saveOrUpdate(employee1);
		return "Updated Successfully";
	}



}
